mesebay = {}
mesebay.credit = {}
mesebay.default_credits = 1000

local selected = ""
local price = ""
local credit = ""

dofile(minetest.get_modpath("mesebay").."/chat_commands.lua")
dofile(minetest.get_modpath("mesebay").."/functions.lua")
dofile(minetest.get_modpath("mesebay").."/interface.lua")
dofile(minetest.get_modpath("mesebay").."/market_list.lua")
dofile(minetest.get_modpath("mesebay").."/nodes.lua")
