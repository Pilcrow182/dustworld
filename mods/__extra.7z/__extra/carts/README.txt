Minetest 0.4 mod: carts
=======================
by PilzAdam

License of source code:
-----------------------
WTFPL

License of media (textures, sounds and models):
-----------------------------------------------
CC-0

Authors of media files:
-----------------------
kddekadenz:
  cart_bottom.png
  cart_side.png
  cart_top.png

Zeg9:
  cart.x
  cart.png

rarkenin:
  cart_rail_*.png
