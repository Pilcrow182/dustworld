Minetest 0.4.7 mod: Simple helicopter
=======================
by Pavel_S

License of source code:
-----------------------
WTFPL

License of media (textures and sounds):
---------------------------------------
WTFPL

