Chatplus
--------

License: CC-BY-SA to Rubenwardy

Commands
========

* /ignore [name] - ignore a player
* /unignore [name] - unignore a player
* /mail [name] [msg] - message a player (online or offline!)
* /inbox - open your inbox
* /inbox clear - clear your inbox

HUD
===

This mod adds a new message icon to the HUD. If HUDs are not supported, no icon is added.