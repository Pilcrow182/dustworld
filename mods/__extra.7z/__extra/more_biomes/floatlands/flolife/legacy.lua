minetest.register_alias("flolands:stair_floatoak", "flolife:stair_floatoak")
minetest.register_alias("flolands:stair_floatoak_upside_down", "flolife:stair_floatoak_upside_down")
minetest.register_alias("flolands:slab_floatoak", "flolife:slab_floatoak")
minetest.register_alias("flolands:slab_floatoak_upside_down", "flolife:slab_floatoak_upside_down")
