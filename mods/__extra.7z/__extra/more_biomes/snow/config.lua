--This file contains configuration options for snow mod.

--Enables falling snow.
snow.enable_snowfall = false

--Enables debuging.
snow.debug = false

--Enables smooth transition of biomes.
snow.smooth = true
