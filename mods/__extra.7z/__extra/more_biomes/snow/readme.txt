   _____                       __  __           _ 
  / ____|                     |  \/  |         | |
 | (___  _ __   _____      __ | \  / | ___   __| |
  \___ \| '_ \ / _ \ \ /\ / / | |\/| |/ _ \ / _` |
  ____) | | | | (_) \ V  V /  | |  | | (_) | (_| |
 |_____/|_| |_|\___/ \_/\_/   |_|  |_|\___/ \__,_|
  
By Splizard, bob and cornernote.

Forum post: http://minetest.net/forum/viewtopic.php?id=2290
Github: https://github.com/Splizard/minetest-mod-snow

INSTALL:
----------
Place this folder in your minetest mods folder.

NOTICE
While this mod is installed you may experience slow map loading while a snow biome is generated.

USAGE:
-------
If you walk around a bit you will find snow biomes scattered around the world.

There are nine biome types:
* Normal
* Icebergs
* Icesheet
* Broken icesheet
* Icecave
* Coast
* Alpine
* Snowy
* Plain
  
Snow can be picked up and thrown as snowballs or crafted into snow blocks.
Snow and ice melts when near warm blocks such as torches or igniters such as lava.
Snow blocks freeze water source blocks around them.
Moss can be found in the snow, when moss is placed near cobble it spreads.
Christmas trees can be found when digging pine needles.

CRAFTING:
-----------
Snow Block:

Snowball    Snowball
Snowball    Snowball

Snow Brick:

Snow Block    Snow Block
Snow Block    Snow Block

UNINSTALL:
------------
Simply delete the folder snow from the mods folder.

CHANGELOG:
------------
Version 1.4

    New biomes, snowy and plain
    
    Christmas Trees
    
    Snowfall
    
Version 1.3

    Smooth transitions
    
    Snow Bricks

Version 1.2

    Pine trees
    
    Moss
    
    Alpine biomes
	
    Dry shrubs

Version 1.1

    Better mapgen

Version 1.0

    Initial release
