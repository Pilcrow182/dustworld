 _______  ______    _______  _______  _______ 
|       ||    _ |  |       ||       ||       |
|_     _||   | ||  |    ___||    ___||  _____|
  |   |  |   |_||_ |   |___ |   |___ | |_____ 
  |   |  |    __  ||    ___||    ___||_____  |
  |   |  |   |  | ||   |___ |   |___  _____| |
  |___|  |___|  |_||_______||_______||_______|

BY:             bas080
DESCRIPTION:    Bigger trees but still tiny trees
VERSION:        1.5
LICENCE:        WTFPL
FORUM:          http://forum.minetest.net/viewtopic.php?id=2344

Changelog
---------
1.5
* Trees
 - Updated jungletree
 - Updated mangrovetree
 - Added conifertree
 - Wood node defs and craft
 - Fixed spawning
 - Removed some mangrovetree nodes
 - Added aliases
 - Improved some textures

1.0
* Trees
 - Palm
 - Mangrove
 - Jungle
* Spawning of trees
