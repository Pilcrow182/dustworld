.png's:
default_water_source_animated.png
default_water_flowing_animated.png
RealBadAngel's animated water (WTFPL)

Code:
minetest/games/minetest_game/mods/default/nodes.lua --> water

Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>
GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.
