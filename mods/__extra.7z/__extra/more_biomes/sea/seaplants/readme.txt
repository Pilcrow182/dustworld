Sounds:
sounds = default.node_sound_leaves_defaults(),

Copyright (C) 2010-2012 celeron55, Perttu Ahola <celeron55@gmail.com>

Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/


.png's:
default_sand.png
VanessaE (WTFPL)

default_dirt.png
Cisoun's WTFPL texture pack


Code:
minetest/games/minetest_game/mods/default/mapgen.lua --> ore generation

Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>
GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.