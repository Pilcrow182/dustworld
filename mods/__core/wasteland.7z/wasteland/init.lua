wasteland = {}
dofile(minetest.get_modpath("wasteland").."/landgen.lua")
dofile(minetest.get_modpath("wasteland").."/nodes.lua")
dofile(minetest.get_modpath("wasteland").."/abms.lua")
dofile(minetest.get_modpath("wasteland").."/gravity.lua")
