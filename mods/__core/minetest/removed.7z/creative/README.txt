Minetest Game mod: creative
===========================
See license.txt for license information.

Authors of source code
----------------------
Originally by Perttu Ahola (celeron55) <celeron55@gmail.com> (MIT)
Jean-Patrick G. (kilbith) <jeanpatrick.guerrero@gmail.com> (MIT)

Author of media (textures)
--------------------------
paramat (CC BY-SA 3.0):
* creative_prev_icon.png
* creative_next_icon.png
* creative_search_icon.png
* creative_clear_icon.png
* creative_trash_icon.png derived from a texture by kilbith (CC BY-SA 3.0)
