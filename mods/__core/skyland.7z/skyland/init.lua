skyland = {}

local clone_item = function(name, newname, newdef)
	local fulldef = {}
	local olddef = minetest.registered_items[name]
	if not olddef then return false end
	for k,v in pairs(olddef) do fulldef[k]=v end
	for k,v in pairs(newdef) do fulldef[k]=v end
	minetest.register_item(":"..newname, fulldef)
end

clone_item("air", "skyland:void", {damage_per_second = 20})
clone_item("air", "skyland:surface", {description = "Island Surface"})

minetest.register_on_mapgen_init(function(mgparams)
	minetest.set_mapgen_params({mgname="singlenode"})
end)

minetest.register_on_generated(function(minp, maxp, seed)
	local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
	local a = VoxelArea:new{
		MinEdge={x=emin.x, y=emin.y, z=emin.z},
		MaxEdge={x=emax.x, y=emax.y, z=emax.z},
	}

	local data = vm:get_data()

	local c_obs = minetest.get_content_id("default:obsidian")
	local c_air = minetest.get_content_id("air")
	local c_void = minetest.get_content_id("skyland:void")

	for z = minp.z, maxp.z do
		for y = minp.y, maxp.y do
			for x = minp.x, maxp.x do
				local vi = a:index(x, y, z)
				if z == 0 and y == 0 and x == 0 then
					data[vi] = c_obs
				elseif y <= -100 then
					data[vi] = c_void
				else
					data[vi] = c_air
				end
			end
		end
	end

	vm:set_data(data)
	vm:write_to_map(data)
end)

local n0 = {name = "air"}
local n1 = {name = "default:dirt"}
local n2 = {name = "default:dirt_with_grass"}
local n3 = {name = "skyland:surface"}

local map = {
	size = {x = 7, y = 6, z = 7},
	data = {
		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n1, n0, n0, n0,
		n0, n0, n2, n2, n2, n0, n0,
		n0, n0, n3, n3, n3, n0, n0,

		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n1, n0, n0, n0,
		n0, n0, n1, n1, n1, n0, n0,
		n0, n2, n2, n2, n2, n2, n0,
		n0, n3, n3, n3, n3, n3, n0,

		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n1, n0, n0, n0,
		n0, n0, n1, n1, n1, n0, n0,
		n0, n1, n1, n1, n1, n1, n0,
		n2, n2, n2, n2, n2, n2, n2,
		n3, n3, n3, n3, n3, n3, n3,

		n0, n0, n0, n1, n0, n0, n0,
		n0, n0, n1, n1, n1, n0, n0,
		n0, n1, n1, n1, n1, n1, n0,
		n1, n1, n1, n1, n1, n1, n1,
		n2, n2, n2, n2, n2, n2, n2,
		n3, n3, n3, n3, n3, n3, n3,

		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n1, n0, n0, n0,
		n0, n0, n1, n1, n1, n0, n0,
		n0, n1, n1, n1, n1, n1, n0,
		n2, n2, n2, n2, n2, n2, n2,
		n3, n3, n3, n3, n3, n3, n3,

		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n1, n0, n0, n0,
		n0, n0, n1, n1, n1, n0, n0,
		n0, n2, n2, n2, n2, n2, n0,
		n0, n3, n3, n3, n3, n3, n0,

		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n0, n0, n0, n0,
		n0, n0, n0, n1, n0, n0, n0,
		n0, n0, n2, n2, n2, n0, n0,
		n0, n0, n3, n3, n3, n0, n0,
	}
}

skyland.spawn_island = function(pos)
	if minetest.get_node(pos).name == "ignore" then
		minetest.log("action", "waiting for "..minetest.pos_to_string(pos).." to stop being 'ignore'...")
		return minetest.after(0.1, function() return skyland.spawn_island(pos) end)
	else
		local island = io.open(minetest.get_worldpath() .. "/island.txt","r")
		if not island then
			minetest.log("action", "generating sky island")
			island = io.open(minetest.get_worldpath() .. "/island.txt","w")
			island:write(minetest.pos_to_string(pos))
			minetest.place_schematic(pos, map, 0, nil, true)
		end
		io.close(island)
	end
end

minetest.register_on_newplayer(function(player)
	local spawnpoint = playerspawn.get(player:get_player_name())
	if not spawnpoint then
		spawnpoint = {x=0, y=0.5, z=0}
		playerspawn.set(player:get_player_name(), spawnpoint)
	end
	player:moveto(spawnpoint)

	local inv = player:get_inventory()
	for _,stack in ipairs({"survivalist:apple_sapling 1", "bonemeal:bonemeal 99", "survivalist:shears", "survivalist:whetstone"}) do
		inv:add_item("main", stack)
	end

	return skyland.spawn_island({x=-3, y=-4, z=-3})
end)

minetest.register_abm({
	label = "Bone decay",
	nodenames = {"bones:bones"},
	neighbors = {"skyland:void"},
	interval = 1,
	chance = 1,
	catch_up = false,
	action = function(pos)
		if pos.y <= -100 then
			minetest.set_node(pos, {name="skyland:void"})
		else
			minetest.remove_node(pos)
		end
	end,
})

