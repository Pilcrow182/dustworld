#!/bin/bash
convert ${1} -crop 32x4+0+2 +repage -gravity south -background transparent -extent 32x32\! +repage -rotate   0 1.png
convert ${1} -crop 32x4+0+2 +repage -gravity south -background transparent -extent 32x32\! +repage -rotate  90 2.png
convert ${1} -crop 32x4+0+2 +repage -gravity south -background transparent -extent 32x32\! +repage -rotate 180 3.png
convert ${1} -crop 32x4+0+2 +repage -gravity south -background transparent -extent 32x32\! +repage -rotate 270 4.png

convert 1.png 2.png -composite 3.png -composite 4.png -composite ductworks_${2}duct_input.png

convert ${1} -crop 32x4+0+6 +repage -gravity north -background transparent -extent 32x32\! +repage 3.png

convert 1.png 2.png -composite 3.png -composite 4.png -composite ductworks_${2}duct_output.png

rm -f 1.png 2.png 3.png 4.png

