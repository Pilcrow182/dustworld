sfinv.override_page("sfinv:crafting", {
	title = "Crafting",
	get = function(self, player, context)
		return sfinv.make_formspec(player, context, [[
				list[current_player;craft;3.5,0.5;3,3;]
				image[6.5,1.5;1,1;gui_furnace_arrow_bg.png^[transformR270]
				list[current_player;craftpreview;7.5,1.5;1,1;]
				list[current_player;main;0,4.7;10,1;]
				list[current_player;main;0,5.85;10,3;10]
				listring[current_player;main]
				listring[current_player;craft]
				image[0,4.75;1,1;gui_hb_bg.png]
				image[1,4.75;1,1;gui_hb_bg.png]
				image[2,4.75;1,1;gui_hb_bg.png]
				image[3,4.75;1,1;gui_hb_bg.png]
				image[4,4.75;1,1;gui_hb_bg.png]
				image[5,4.75;1,1;gui_hb_bg.png]
				image[6,4.75;1,1;gui_hb_bg.png]
				image[7,4.75;1,1;gui_hb_bg.png]
				image[8,4.75;1,1;gui_hb_bg.png]
				image[9,4.75;1,1;gui_hb_bg.png]
			]], false, "size[10,8.6]")
	end
})

minetest.register_on_joinplayer(function(player)
	player:get_inventory():set_size("main", 10*4)
	player:hud_set_hotbar_itemcount(10)
end)

function sfinv.get_homepage_name(player)
	return "sfinv:crafting"
end
