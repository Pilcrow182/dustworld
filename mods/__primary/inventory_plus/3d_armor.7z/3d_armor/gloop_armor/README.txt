[mod] Gloopores Armor [gloop_armor]
========================================

depends: default, 3d_armor

Adds an Alatro armor set.
